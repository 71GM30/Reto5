package com.motorbikes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorbikesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotorbikesApplication.class, args);
	}

}
